@extends('loanmanagement::layouts.master')

@section('content')
<div class="content-wrapper">
    <h1>Loan Management</h1>

    <p>Module: {!! config('loanmanagement.name') !!}</p>
</div>
@endsection
